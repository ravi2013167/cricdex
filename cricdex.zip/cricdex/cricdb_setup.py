import os
import sys
from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine
#from passlib.apps import custom_app_context as pwd_context

import random, string
from itsdangerous import(TimedJSONWebSignatureSerializer as Serializer, BadSignature, SignatureExpired)

Base = declarative_base()
secret_key = ''.join(random.choice(string.ascii_uppercase + string.digits) for x in xrange(32))


class Team(Base):
    __tablename__ = 'team'

    id = Column(Integer, primary_key = True)
    name = Column(String(80), nullable = False)


class Player(Base):
    __tablename__ = 'player'

    id = Column(Integer, primary_key = True)
    team_id = Column(Integer, primary_key = False)
    name = Column(String(80), nullable = False)
    country = Column(String(250), nullable = False)
    info = Column(String(250), nullable = False)
    career = Column(String(250), nullable = False)
    batting_style = Column(String(250), nullable = False)
    bowling_style = Column(String(250), nullable = False)
    picture = Column(String(250))

class PlayerRuns(Base):
    __tablename__ = 'player_runs'

    id = Column(Integer, primary_key = True)
    player_id = Column(Integer, primary_key = False)
    against_team = Column(String(80), nullable = False)
    year = Column(Integer, primary_key = False)
    runs = Column(Integer, primary_key = False)
    matches = Column(Integer, primary_key = False)

class Batsman(Base):
    __tablename__ = 'batsman'

    shot_id = Column(Integer, primary_key = True) 
    player_id = Column(Integer, primary_key = False)
    var = Column(Integer, primary_key = False)
    shot = Column(String(280), nullable = False)
    type = Column(String(280), nullable = False)
    video_id = Column(Integer, primary_key = False)
    stance = Column(String(280), nullable = False)
    foot = Column(String(280), nullable = False)
    elevation = Column(String(280), nullable = False)
    backlift = Column(String(280), nullable = False)
    mode = Column(String(280), nullable = False)
    feet = Column(String(280), nullable = False)
    #user = relationship(User)
    #menuItems = relationship("MenuItem", cascade="all, delete-orphan")
    '''@property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'name': self.name,
            'id': self.id,
        }
'''
class Comments(Base):
    __tablename__ = 'comments'

    user_id = Column(Integer, primary_key = True) 
    
    username = Column(String(280), nullable = False)
    
    comment = Column(String(280), nullable = False)
    
    reason = Column(String(280), nullable = False)
    
    #user = relationship(User)
    #menuItems = relationship("MenuItem", cascade="all, delete-orphan")
    '''@property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'name': self.name,
            'id': self.id,
        }
'''

class User(Base):
    __tablename__ = 'user'
    id = Column(Integer, primary_key=True)
    username = Column(String(32), index=True)
    picture = Column(String)
    email = Column(String)
    password_hash = Column(String(64))

    def hash_password(self, password):
        self.password_hash = pwd_context.encrypt(password)

    def verify_password(self, password):
        return pwd_context.verify(password, self.password_hash)

    def generate_auth_token(self, expiration=600):
        s = Serializer(secret_key, expires_in = expiration)
        return s.dumps({'id': self.id })

    @staticmethod
    def verify_auth_token(token):
        s = Serializer(secret_key)
        try:
            data = s.loads(token)
        except SignatureExpired:
            #Valid Token, but expired
            return None
        except BadSignature:
            #Invalid Token
            return None
        user_id = data['id']
        return user_id


class Bowler(Base):
    __tablename__ = 'bowler'

    player_id = Column(Integer, primary_key = True)
    video_id = Column(Integer, primary_key = True)
    ball_type = Column(String(80), nullable = False)
    speed = Column(String(80), nullable = False)
    length = Column(String(80), nullable = False)
    angle = Column(String(80), nullable = False)
    line = Column(String(80), nullable = False)
    
class Fielder(Base):
    __tablename__ = 'fielder'

    id = Column(Integer, primary_key = True)
    field_type = Column(String(80), nullable = False)
    position = Column(String(80), nullable = False)
          

class PlayerStrength(Base):
    __tablename__ = 'player_strength'

    id = Column(Integer, primary_key = True)
    strength_detail = Column(String(80), nullable = False)
    

class PlayerWeakness(Base):
    __tablename__ = 'player_weakness'

    id = Column(Integer, primary_key = True)
    weakness_detail = Column(String(80), nullable = False)

class PlayerMoment(Base):
    __tablename__ = 'player_moment'

    id = Column(Integer, primary_key = True)
    moment_type = Column(String(80), nullable = False)
    moment_name = Column(String(80), nullable = False)

class Video(Base):
    __tablename__ = 'video'

    video_id = Column(Integer, primary_key = True)
    player_id = Column(Integer, primary_key = False)
    video_type = Column(String(80), nullable = False)
    thumbnail = Column(String(80), nullable = False)
    video_name = Column(String(80), nullable = False)
    video_desc = Column(String(80))
    video_url = Column(String(980), nullable = False)
    vs = Column(String(280), nullable = False)
    opponent = Column(String(280), nullable = False)
    vs_id = Column(String(280), nullable = False)
    result = Column(String(80), nullable = False)

#class MenuItem(Base):
    '''__tablename__ = 'menu_item'

    id = Column(Integer, primary_key=True)
    name = Column(String(80), nullable=False)
    course = Column(String(250))
    description = Column(String(250))
    price = Column(String(8))
    restaurant_id = Column(Integer, ForeignKey('restaurant.id'))
    restaurant = relationship(Restaurant)
    user_id = Column(Integer, ForeignKey('user.id'))
    user = relationship(User)



    @property
    def serialize(self):
        return {
            'name': self.name,
            'description': self.description,
            'id': self.id,
            'price': self.price,
            'course': self.course,
        }


'''

engine = create_engine('sqlite:///cricdb.db')
'''
from sqlalchemy import MetaData
meta = MetaData()
import contextlib
with contextlib.closing(engine.connect()) as con:
    trans = con.begin()
    for table in reversed(meta.sorted_tables):
        con.execute(table.delete())
    trans.commit()
'''

Base.metadata.create_all(engine)
