from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from cricdb_setup import Team, Player, Base, Batsman, Bowler, Fielder, PlayerStrength, PlayerWeakness, PlayerMoment, Video

engine = create_engine('sqlite:///cricdb.db')
# Bind the engine to the metadata of the Base class so that the
# declaratives can be accessed through a DBSession instance
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
# A DBSession() instance establishes all conversations with the database
# and represents a "staging zone" for all the objects loaded into the
# database session object. Any change made against the objects in the
# session won't be persisted into the database until you call
# session.commit(). If you're not happy about the changes, you can
# revert all of them back to the last commit by calling
# session.rollback()
session = DBSession()

Team1 = Team(id = 1, name='India')

session.add(Team1)
session.commit()

Team1 = Team(id = 2, name='Australia')

session.add(Team1)
session.commit()

# Create dummy player
Player1 = Player(id = 1, team_id = 1, name="Virat Kohli", country="India", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='vk.jpg')
session.add(Player1)
session.commit()


# Create dummy player
Player1 = Player(id = 6, team_id = 1, name="Karun Nair", country="India", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='1.jpg')
session.add(Player1)
session.commit()

# Create dummy player
Player1 = Player(id = 3, team_id = 1, name="Mahendra Singh Dhoni", country="India", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='msd.jpg')
session.add(Player1)
session.commit()

# Create dummy player
Player1 = Player(id = 4, team_id = 1, name="R. Ashwin", country="India", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='3.jpg')
session.add(Player1)
session.commit()

# Create dummy player
Player1 = Player(id = 5, team_id = 1, name="Jayant Yadav", country="India", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='2.jpg')
session.add(Player1)
session.commit()

Player1 = Player(id = 2, team_id = 2, name="Mitchel Johnson", country="Australia", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='mj.jpg')
session.add(Player1)
session.commit()


Player1 = Player(id = 7, team_id = 2, name="Mitchel Starc", country="Australia", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='ms.jpg')
session.add(Player1)
session.commit()


Player1 = Player(id = 8, team_id = 2, name="Shane Watson", country="Australia", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='sw.jpg')
session.add(Player1)
session.commit()


Player1 = Player(id = 9, team_id = 2, name="Mathew Wade", country="Australia", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='mw.jpg')
session.add(Player1)
session.commit()


Player1 = Player(id = 10, team_id = 2, name="James Faulkner", country="Australia", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='jf.jpg')
session.add(Player1)
session.commit()

Player1 = Player(id = 11, team_id = 2, name="Mitchel Marsh", country="Australia", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='mm.jpg')
session.add(Player1)
session.commit()


Player1 = Player(id = 12, team_id = 2, name="Glenn Maxwell", country="Australia", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='gm.jpg')
session.add(Player1)
session.commit()


Player1 = Player(id = 13, team_id = 2, name="Adam Zampa", country="Australia", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='az.jpg')
session.add(Player1)
session.commit()


Player1 = Player(id = 14, team_id = 2, name="Steve Smith", country="Australia", info='Born Nov 05, 1988 (28 years) Birth Place Delhi Nickname Kohli Height 5 ft 9 in (175 cm) Role Batsman Batting Style Right Handed Bat Bowling Style Right-arm medium', career='blank', batting_style='blank', bowling_style='blank',
             picture='ss.jpg')
session.add(Player1)
session.commit()

'''
Batsman1 = Batsman(shot_id = 1, player_id=1, shot="Straight Drive", var = 1, type='grounded', video_id=1)

session.add(Batsman1)
session.commit()

Batsman1 = Batsman(shot_id = 2, player_id=1, shot="Pull", var = 1, type = 'grounded', video_id=2)

session.add(Batsman1)
session.commit()

Batsman1 = Batsman(shot_id = 3, player_id=1, shot="Leg Glance", var = 1, type = 'grounded', video_id=3)

session.add(Batsman1)
session.commit()
'''
Batsman1 = Batsman(shot_id = 4, player_id=1, shot="Cover_Drive", var = 1, type = 'grounded', video_id=4, stance = 'Side On', foot = 'Front Foot', elevation = 'Grounded', backlift = 'High', mode = 'Attack')

session.add(Batsman1)
session.commit()


Batsman1 = Batsman(shot_id = 8, player_id=1, shot="Cover_Drive", var = 2, type = 'grounded', video_id=8, stance = 'Side On', foot = 'Front Foot', elevation = 'Grounded', backlift = 'High', mode = 'Attack')

session.add(Batsman1)
session.commit()

Batsman1 = Batsman(shot_id = 5, player_id=1, shot="Cut", var = 1, type = 'Lofted', video_id=5, stance = 'Side On', foot = 'Front Foot', elevation = 'Lofted', backlift = 'High', mode = 'Attack')

session.add(Batsman1)
session.commit()

Batsman1 = Batsman(shot_id = 6, player_id=1, shot="Sweep", var = 1, type = 'Lofted', video_id=6, stance = 'Side On', foot = 'Front Foot', elevation = 'Lofted', backlift = 'High', mode = 'Attack')

session.add(Batsman1)
session.commit()

Batsman1 = Batsman(shot_id = 7, player_id=1, shot="Guide", var = 1, type = 'Lofted', video_id=7, stance = 'Side On', foot = 'Front Foot', elevation = 'Lofted', backlift = 'High', mode = 'Attack')

session.add(Batsman1)
session.commit()

Batsman1 = Batsman(shot_id = 10, player_id=1, shot="Guide", var = 1, type = 'Lofted', video_id=10, stance = 'Side On', foot = 'Front Foot', elevation = 'Lofted', backlift = 'High', mode = 'Attack')

session.add(Batsman1)
session.commit()

Batsman1 = Batsman(shot_id = 11, player_id=1, shot="Guide", var = 1, type = 'Lofted', video_id=11, stance = 'Side On', foot = 'Front Foot', elevation = 'Lofted', backlift = 'High', mode = 'Attack')

session.add(Batsman1)
session.commit()

Bowler1 = Bowler(player_id = 2, video_id = 9, ball_type='seam', speed='150', length='good', angle='over', line='off stump' )

session.add(Bowler1)
session.commit()

'''

Batsman1 = Batsman(shot_id = 6, player_id=1, shot="On Drive", var = 1, type = 'grounded', video_id=6)

session.add(Batsman1)
session.commit()

Batsman1 = Batsman(shot_id = 7, player_id=1, shot="Wristy Flick", var = 1, type = 'grounded', video_id=7)

session.add(Batsman1)
session.commit()

Batsman1 = Batsman(shot_id = 8, player_id=1, shot="Square Cut", var = 1, type = 'grounded', video_id=8)

session.add(Batsman1)
session.commit()

Batsman1 = Batsman(shot_id = 9, player_id=1, shot="Guide", var = 1, type = 'grounded', video_id=9)

session.add(Batsman1)
session.commit()
'''

Video1 = Video(video_id = 4, player_id=1, video_type='batsman', thumbnail = 'vk_cover_drive.png', video_name='Cover_Drive', video_desc = 'grounded', video_url='vk_cover_drive.webm', vs = 'Ryan Harris', opponent = 'Australia', vs_id = '3', result='Four')
session.add(Video1)
session.commit()

Video1 = Video(video_id = 10, player_id=1, video_type='batsman', thumbnail = 'vk_cover_drive.png', video_name='Cover_Drive', video_desc = 'grounded', video_url='vk_flick.mp4', vs = 'Ryan Harris', opponent = 'Australia', vs_id = '3', result='Four')
session.add(Video1)
session.commit()

Video1 = Video(video_id = 11, player_id=1, video_type='batsman', thumbnail = 'vk_cover_drive.png', video_name='Cover_Drive', video_desc = 'grounded', video_url='vk_pull.mp4', vs = 'Ryan Harris', opponent = 'Australia', vs_id = '3', result='Four')
session.add(Video1)
session.commit()

Video1 = Video(video_id = 5, player_id=1, video_type='batsman', thumbnail = 'vk_cut.png', video_name='Cut', video_desc = 'Lofted', video_url='vk_lofted_cut.webm', vs = 'Mitchell Johnson', opponent = 'Australia', vs_id = '2', result='Four')
session.add(Video1)
session.commit()

Video1 = Video(video_id = 6, player_id=1, video_type='batsman', thumbnail = 'vk_cut.png', video_name='Cut', video_desc = 'Lofted', video_url='vk_sweep.mp4', vs = 'Mitchell Johnson', opponent = 'Australia', vs_id = '2', result='Four')
session.add(Video1)
session.commit()

Video1 = Video(video_id = 7, player_id=1, video_type='batsman', thumbnail = 'vk_cut.png', video_name='Cut', video_desc = 'Lofted', video_url='vk_guide.mp4', vs = 'Mitchell Johnson', opponent = 'Australia', vs_id = '2', result='Four')
session.add(Video1)
session.commit()

Video1 = Video(video_id = 8, player_id=1, video_type='batsman', thumbnail = 'vk_cut.png', video_name='Cover_Drive', video_desc = 'Lofted', video_url='vk_cover_drive_2.webm', vs = 'Mitchell Johnson', opponent = 'Australia', vs_id = '2', result='Four')
session.add(Video1)
session.commit()

Video1 = Video(video_id = 9, player_id=2, video_type='bowler', thumbnail = 'mj_seam.png', video_name='Cover_Drive', video_desc = 'Lofted', video_url='mj_seam.webm', vs = 'Mitchell Johnson', opponent = 'Australia', vs_id = '2', result='Out')
session.add(Video1)
session.commit()

'''
Video1 = Video(video_id = 2, player_id=1, video_type='batsman', thumbnail = '2.jpg', video_name='Pull', video_desc = 'grounded', video_url='vk_pull.mp4')
session.add(Video1)png
session.commit()

Video1 = Video(video_id = 7, player_id=1, video_type='batsman', thumbnail = '2.jpg', video_name='Hook', video_desc = 'grounded', video_url='vk_hook.mp4')
session.add(Video1)
session.commit()

Video1 = Video(video_id = 5, player_id=1, video_type='batsman', thumbnail = '2.jpg', video_name='On Drive', video_desc = 'grounded', video_url='vk_on_drive.mp4')
session.add(Video1)
session.commit()

Video1 = Video(video_id = 3, player_id=1, video_type='batsman', thumbnail = '2.jpg', video_name='Leg Glance', video_desc = 'grounded', video_url='vk_leg_glance.mp4')
session.add(Video1)
session.commit()

Video1 = Video(video_id = 8, player_id=1, video_type='batsman', thumbnail = '2.jpg', video_name='Square Cut', video_desc = 'lofted', video_url='vk_square_cut.mp4')
session.add(Video1)
session.commit()

Video1 = Video(video_id = 9, player_id=1, video_type='batsman', thumbnail = '2.jpg', video_name='Guide', video_desc = 'grounded', video_url='vk_guide.mp4')
session.add(Video1)
session.commit()
'''

print ("added menu items!")