from flask import Flask, render_template, request, redirect, jsonify, url_for, flash, abort, g
from livereload import Server, shell
from bs4 import BeautifulSoup
from flask.ext.login import LoginManager,login_user
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask import request, redirect, url_for, render_template

from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
from cricdb_setup import Player, User, Team, Base, Batsman, Bowler, Fielder, PlayerStrength, PlayerWeakness, PlayerMoment, Video, Comments

import requests
import random
import string

from oauth2client.client import flow_from_clientsecrets
from oauth2client.client import FlowExchangeError
from flask import session as login_session
from itsdangerous import(TimedJSONWebSignatureSerializer as Serializer, BadSignature, SignatureExpired)
from pymongo import MongoClient
secret_key = ''.join(random.choice(string.ascii_uppercase + string.digits) for x in xrange(32))


from flask.ext.httpauth import HTTPBasicAuth
auth = HTTPBasicAuth()

import os
import sys
import json
from flask import make_response
import requests

video_dir = './static/videos'

app = Flask(__name__)

CLIENT_ID = json.loads(
    open('client_secrets.json', 'r').read())['web']['client_id']
APPLICATION_NAME = "CricDex"
    
count = 0
# Connect to Database and create database session
engine = create_engine('sqlite:///cricdb.db')

Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()

# Show all teams
@app.route('/index/', methods=['GET','POST'])
def showTeams():
    if request.method == 'POST':
      pla = session.query(Player).filter_by(name = request.form['name']).one()
      return redirect(url_for('showProfile', player_id = pla.id)) 

    teams = session.query(Team).order_by(asc(Team.name))
    players = session.query(Player).all()
    if 'username' not in login_session:
        return render_template('allteams.html', teams=teams, players=players)

    return render_template('restaurants.html', restaurants=restaurants)

@app.route('/')
@app.route('/home', methods=['GET','POST'])
def showHome():
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != 'admin':
            error = "Invalid"
        else:
            return redirect(url_for('showTeams'))
    return render_template('home.html')

#@app.route('/index/<int:player_id>', methods=['POST'])
#def hello():
#    name=request.form['tb1']
#    email=request.form['tb2']
#    return render_template('allteams.html', name=name, email=email)
@app.route('/index/<int:player_id>/comments', methods=['GET','POST'])
def showComment(player_id):
    player = session.query(Player).filter_by(
        id=player_id).one()
    if request.method == 'POST':
        xyz = Comments(username=request.form['username'], comment=request.form['comment'], reason=request.form['reason'])
        session.add(xyz)
        session.commit()
        comments = session.query(Comments).all()
        return render_template('all_comments.html', player=player, comment = comments)
    else:
        return render_template('comments.html', player=player)

@app.route('/index/<int:player_id>/bat')
def showShots(player_id):
    player = session.query(Player).filter_by(
        id=player_id).one()
    
    shots = session.query(Batsman).filter_by(
        player_id=player_id).all()

    videos = session.query(Video).filter_by(
        player_id=player_id).all()

    video_files = [f for f in os.listdir(video_dir) if f.endswith('mp4')]
    video_files_number = len(video_files)

    if 'username' not in login_session or creator.id != login_session['user_id']:
        return render_template('batsman.html', vieo_files_number = video_files_number,
                        video_files = video_files, player=player, shots=shots, videos = videos)
    return render_template('menu.html', items=items, restaurant=restaurant, creator=creator)

@app.route('/index/<int:player_id>/comments')
def showComments(player_id):
    player = session.query(Player).filter_by(
        id=player_id).one()
    
    return render_template('comments.html', player=player)


@app.route('/index/<int:player_id>/bowl')
def showDeliveries(player_id):
    player = session.query(Player).filter_by(
        id=player_id).one()
    
    balls = session.query(Bowler).filter_by(
        player_id=player_id).all()

    videos = session.query(Video).filter_by(
        player_id=player_id).all()

    video_files = [f for f in os.listdir(video_dir) if f.endswith('mp4')]
    video_files_number = len(video_files)

    if 'username' not in login_session or creator.id != login_session['user_id']:
        return render_template('bowler.html', vieo_files_number = video_files_number,
                        video_files = video_files, player=player, balls=balls, videos = videos)
    return render_template('menu.html', items=items, restaurant=restaurant, creator=creator)


@app.route('/index/<int:player_id>/')
def showProfile(player_id, methods=['GET','POST']):
    if request.method == 'POST':
        flash('hi');

    player = session.query(Player).filter_by(
        id=player_id).one()
    data = []
    
    if 'username' not in login_session or creator.id != login_session['user_id']:
        if(player_id == 1):
            return render_template('playerprofile.html',
                        player=player, player_id=player_id)#, data=data)#LH.tostring(doc, pretty_print = True))
        else:
            return redirect(url_for('showTeams'))
    return render_template('menu.html', items=items, restaurant=restaurant, creator=creator)

CLIENT_ID = json.loads(
    open('client_secrets.json', 'r').read())['web']['client_id']



@auth.verify_password
def verify_password(username_or_token, password):
    #Try to see if it's a token first
    user_id = User.verify_auth_token(username_or_token)
    if user_id:
        user = session.query(User).filter_by(id = user_id).one()
    else:
        user = session.query(User).filter_by(username = username_or_token).first()
        if not user or not user.verify_password(password):
            return False
    g.user = user
    return True



if __name__ == '__main__':
    #app.secret_key = 'super_secret_key'
    #app.debug = True
    #server = Server(app.wsgi_app)
    #server.serve()
    #app.run(host='0.0.0.0', port=5000)
    port = int(os.environ.get('PORT', 5500))
    app.run(host='0.0.0.0', port=port)
